package com.ll.traveler.domain.review.review.entity;

public enum PlaceType {
    GANGWON2,
    GYEONGGI,
    GYEONGGI2,
    ULSAN,
}
