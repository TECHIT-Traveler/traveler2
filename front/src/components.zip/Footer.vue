<template>
    <footer>
        <h1>footer</h1>
    </footer>
</template>

<script>
export default {
}
</script>

<style>
</style>
